<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>mail function</title>
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="bootstrap.min.css">
</head>
<body>


<?php
if(isset($_POST['sendEmail'])){

require 'PHPMailerAutoload.php';
require 'credential.php';

$mail = new PHPMailer;

$mail->SMTPDebug = 4;                               // Enable verbose debug output

$mail->isSMTP();                                      // Set mailer to use SMTP
$mail->Host = 'smtp.gmail.com';  // Specify main and backup SMTP servers
$mail->SMTPAuth = true;                               // Enable SMTP authentication
$mail->Username = EMAIL;                 // SMTP username
$mail->Password = PASS;                           // SMTP password
$mail->SMTPSecure = 'tls';                            // Enable TLS encryption, `ssl` also accepted
$mail->Port = 587;                                    // TCP port to connect to

$mail->setFrom(EMAIL, 'Subhajit');
$mail->addAddress($_POST['email']);     // Add a recipient
// $mail->addAddress('ellen@example.com');               // Name is optional
$mail->addReplyTo(EMAIL);
// $mail->addCC('cc@example.com');
// $mail->addBCC('bcc@example.com');

// $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
// $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name
$mail->isHTML(true);                                  // Set email format to HTML

$mail->Subject = $_POST['subject'];
$mail->Body    = 'This is the HTML message body <b>in bold!</b>';
$mail->AltBody = $_POST['message'];

if(!$mail->send()) {
    echo 'Message could not be sent.';
    echo 'Mailer Error: ' . $mail->ErrorInfo;
} else {
    echo 'Message has been sent';
}

}
?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-sm-6">
                <h4 class="sent-noti"></h4>
                <div class="title text-center">
                    <h2>Contact Us</h2>
                    <hr>
                </div>
                <div class="main-body">
                    <form id="myForm">
                        <label>Name</label>
                        <input type="text" id="name" placeholder="Enater Your Name" class="form-control mb-2" >
                        <label>Email</label>
                        <input type="email" id="email" placeholder="Enater Your Email" class="form-control mb-2" >
                        <label>Message</label>
                        <textarea type="text" id="msg" placeholder="Message" class="form-control mb-2" ></textarea>
                        <button type="submit" class="form-control btn btn-success"  onclick="sendEmail()" value="Sending Successfull">Send</button>
                    </form>
                </div>
            </div>
        </div>
    </div>


</body>
</html>
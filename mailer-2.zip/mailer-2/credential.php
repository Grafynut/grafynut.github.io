<?php
    define('EMAIL', 'subhajit.techsbasket@gmail.com');
    define('PASS', 'Yujikl@.gmail');
?>